package com.salmahmed.videosplitter.activities

import android.Manifest
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION.SDK_INT
import android.os.Bundle
import android.os.Handler
import android.provider.MediaStore
import android.util.Log
import android.view.Window
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.arthenica.mobileffmpeg.Config
import com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL
import com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS
import com.arthenica.mobileffmpeg.FFmpeg
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.InterstitialAd
import com.salmahmed.videosplitter.R
import com.salmahmed.videosplitter.model.URIPathHelper
import com.sasank.roundedhorizontalprogress.RoundedHorizontalProgressBar
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.process_dialog.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit


class HomeActivity : AppCompatActivity() {
    private var progressBar: RoundedHorizontalProgressBar? = null
    private var dialog: Dialog? = null
    private lateinit var root: File
    private lateinit var rootDir: String
    private lateinit var cmd1: Array<String>
    lateinit var format :String
    private val GALLERY = 1
    private val CAMERA = 2
    var doubleBackToExitPressedOnce = false
    private lateinit var mInterstitialAd: InterstitialAd



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        checkPermissions()
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
        mInterstitialAd = InterstitialAd(this)
        mInterstitialAd.adUnitId = getString(R.string.interstitial_ad_id)
        mInterstitialAd.loadAd(AdRequest.Builder().build())

        val cacheDir = externalMediaDirs[0].toString()
        rootDir = "$cacheDir/WhatsappSplit"
        root = File(rootDir)
        if (!root .exists()) {
            root .mkdirs()
        }

        format = SimpleDateFormat("_HHmmss", Locale.US).format(Date())

        tv_camera.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_VIDEO_CAPTURE)
            startActivityForResult(intent, CAMERA)
        }
        tv_gallery.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            intent.type = "video/*"
            startActivityForResult(intent, GALLERY)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_CANCELED) {
            return
        }
        if (data != null) {
            val contentURI = data.data
            val uriPathHelper = URIPathHelper()
            val filePath = uriPathHelper.getPath(this, contentURI!!)
            splitVideo(filePath!!)
        }
    }

    fun splitVideo(path: String) {
        val duration = MediaPlayer.create(this, Uri.fromFile(File(path))).duration
        Log.i("Duration", duration.toString())
        val sec = duration / 1000 % 60
        val min = duration / 1000 / 60 % 60
        val tym = (TimeUnit.MINUTES.toSeconds(min.toLong()) + sec).toInt()
        Log.i("Min", min.toString())
        Log.i("Sec", sec.toString())
        Log.i("Tym", tym.toString())
        Log.i("ROOT_PATH", rootDir)



        if (!root.exists())
            root.mkdirs()


        val videoName = File(root, "VideoPart%03d.mp4")
        cmd1 = arrayOf(
          "-i", path , "-c", "copy", "-map" , "0" , "-segment_time" ,"00:00:30", "-f" ,"segment" , videoName.absolutePath)

         start()

        val executionId = FFmpeg.executeAsync(cmd1) { executionId, returnCode ->

            if (returnCode == RETURN_CODE_SUCCESS) {
                Log.i(Config.TAG, "Async command execution completed successfully.")

                    if (mInterstitialAd.isLoaded) {
                        mInterstitialAd.show()
                    } else {
                        if (dialog != null && dialog!!.isShowing) {
                            startActivity(Intent(this@HomeActivity, ResultActivity::class.java))
                            mInterstitialAd.loadAd(AdRequest.Builder().build())
                            Log.i("TAG", "The interstitial wasn't loaded yet.")
                    }}
                    mInterstitialAd.adListener = object : AdListener() {
                        override fun onAdClosed() {
                            super.onAdClosed()
                            if (dialog != null && dialog!!.isShowing) {
                                startActivity(Intent(this@HomeActivity, ResultActivity::class.java))
                                mInterstitialAd.loadAd(AdRequest.Builder().build())
                            }}
                    }


            } else if (returnCode == RETURN_CODE_CANCEL) {
                Log.i(Config.TAG, "Async command execution cancelled by user.")
                if (dialog != null && dialog!!.isShowing) {
                    dialog!!.dismiss()
                }


            } else {
                Log.i(
                    Config.TAG,
                    String.format(
                        "Async command execution failed with returnCode=%d.", returnCode
                    )
                )
                if (dialog != null && dialog!!.isShowing) {
                    dialog!!.dismiss()
                }
            }



        }



    }


    override fun onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed()
            finishAffinity()
            return
        }
        doubleBackToExitPressedOnce = true
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show()
        Handler().postDelayed({ doubleBackToExitPressedOnce = false }, 2000)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (dialog != null && dialog!!.isShowing) {
            dialog!!.dismiss()
        }
    }

     fun start(){
         dialog = Dialog(this@HomeActivity, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
         dialog!!.requestWindowFeature(Window.FEATURE_NO_TITLE)
         dialog!!.setContentView(R.layout.process_dialog)
         val adView = dialog!!.adView1
         val adRequest = AdRequest.Builder().build()
         adView.loadAd(adRequest)
         progressBar = dialog!!.progress
         progressBar!!.animateProgress(2200, 0, 100)
         Log.i("FINISH", isFinishing.toString())
             if (!isFinishing)
                 dialog!!.show()
     }

    private fun checkPermissions() {
        if(SDK_INT >= Build.VERSION_CODES.M){
            if(ContextCompat.checkSelfPermission(
                    getBaseContext(),
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                    0
                );
            }
            if(ContextCompat.checkSelfPermission(
                    getBaseContext(),
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                    0
                );
            }
        }

    }
}