package com.salmahmed.videosplitter.adapter

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.os.StrictMode
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.view.Window
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.android.gms.ads.AdRequest
import com.salmahmed.videosplitter.R
import com.salmahmed.videosplitter.model.Video1
import kotlinx.android.synthetic.main.play_video_dialog.*
import kotlinx.android.synthetic.main.result_item.view.*
import java.io.File

class ResultAdapter(private val context: Context, val videoList: List<Video1>) :
    RecyclerView.Adapter<ResultAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(context)
            .inflate(R.layout.result_item, parent, false)
        val builder = StrictMode.VmPolicy.Builder()
        StrictMode.setVmPolicy(builder.build())
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return videoList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.setIsRecyclable(false)
        holder.tvName.text = videoList[position].name.replace(".mp4", "")
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(context, Uri.fromFile(File(videoList[position].path)))
        val time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
        if (time!!.matches("0".toRegex())) {
            holder.c1.visibility = GONE
        } else {
            holder.c1.visibility = VISIBLE
        }
        retriever.release()
        Glide.with(context)
            .load(videoList[position].path)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .skipMemoryCache(true)
            .into(holder.ivImg)



        holder.tvShare.setOnClickListener {

            val shareIntent: Intent = Intent().apply {
                action = Intent.ACTION_SEND
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val uri = Uri.parse("file://" + videoList[position].path)
                Log.d("ttt", "file://" + videoList[position].path)
                setPackage("com.whatsapp")
                putExtra(Intent.EXTRA_STREAM, uri)
                type = "video/*"
            }

         //   shareIntent.setPackage("com.whatsapp")
            holder.tvShare.context.startActivity(Intent.createChooser(shareIntent, "Share video"))


        }



        holder.ivPlay.setOnClickListener {
            val dialog = Dialog(context, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setContentView(R.layout.play_video_dialog)
            val adView = dialog.adView1
            val adRequest = AdRequest.Builder().build()
            adView.loadAd(adRequest)
            val videoView = dialog.video_view
            videoView.setVideoURI(Uri.fromFile(File(videoList[position].path)))
            videoView.start()
            videoView.setOnCompletionListener {
                dialog.dismiss()
            }
            dialog.show()
        }
    }

    override fun getItemViewType(position: Int): Int {
        return position
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivImg = view.video_img!!
        val tvName = view.video_name!!
        val tvShare = view.tv_share!!
        val ivPlay = view.iv_play!!
        val c1 = view.v1!!
    }
}
