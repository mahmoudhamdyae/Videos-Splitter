package com.salmahmed.videosplitter.model

class Video1(var id:Int ,var name:String,var path:String)