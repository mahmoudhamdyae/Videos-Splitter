package com.salmahmed.videosplitter.activities

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.gms.ads.AdRequest
import com.salmahmed.videosplitter.R
import com.salmahmed.videosplitter.adapter.ResultAdapter
import com.salmahmed.videosplitter.model.Video1
import kotlinx.android.synthetic.main.activity_result.*
import java.io.File

class ResultActivity : AppCompatActivity() {
    lateinit var root: File
    private lateinit var rootDir: String
    lateinit var format :String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
        rv_video.layoutManager = LinearLayoutManager(this)
        val videoList: ArrayList<Video1> = ArrayList()
        videoList.clear()

        val cacheDir = externalMediaDirs[0].toString()
        rootDir = "$cacheDir/WhatsappSplit"
        root = File(rootDir)
        if (!root .exists()) {
            root .mkdirs()
        }
        for (i in root.listFiles()!!.indices) {
            val files = root.listFiles()!![i]
            if (files.absolutePath.contains(".mp4")) {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(this, Uri.fromFile(files))
                val video = Video1(i, files.name, files.absolutePath)
                retriever.release()
                videoList.add(video)
            }
        }
        val sortedList = videoList.sortedBy { it.name }
        val adapter = ResultAdapter(this, sortedList)
        rv_video.adapter = adapter
        back.setOnClickListener {
            onBackPressed()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }


    private fun deleteRecursive(fileOrDirectory: File) {
        if (fileOrDirectory.isDirectory) {
            for (child in fileOrDirectory.listFiles()!!) {
                deleteRecursive(child)
            }
        }
        fileOrDirectory.delete()
    }

    override fun onDestroy() {
        super.onDestroy()
        deleteRecursive(root)
    }
}